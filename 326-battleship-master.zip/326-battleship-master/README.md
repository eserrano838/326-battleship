# 326-battleship
CPSC 326 group project. Using C# to create a multiplayer battleship game
